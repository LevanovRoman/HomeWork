from django.shortcuts import render
import datetime
import time

menu = [
    {'title':'Задание ', 'url_name': 'index'},
    {'title':'Задание 1', 'url_name': 'task_1'},
    {'title':'Задание 2', 'url_name': 'task_2'},
    {'title':'Задание 3', 'url_name': 'task_3'},
]

def index(request):
    return render(request, 'first_app/index.html', {"menu": menu, "title": "Домашняя работа"})

def task_1(request):
    year = datetime.date.today()
    t = time.localtime()
    current_time = time.strftime("%H:%M:%S", t)
    context = {"menu": menu, "title": "Домашняя работа", "time":current_time, "date": year}
    return render(request, 'first_app/task_1.html', context=context)

def task_2(request):
    w = range(1, 10)
    context = {"menu": menu, "title": "Домашняя работа", "numbers": w}
    return render(request, 'first_app/task_2.html', context=context)

def task_3(request):
    today = datetime.date.today()
    first_day_year = datetime.date(today.year, 1, 1)
    delta = datetime.timedelta(days=256)
    prog_day = first_day_year + delta
    context = {"menu": menu, "title": "Домашняя работа", "date": prog_day}
    return render(request, 'first_app/task_3.html', context=context)


# Create your views here.

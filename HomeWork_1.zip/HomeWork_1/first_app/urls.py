from django.urls import path
from .views import *

urlpatterns = [
    path('', index, name='index'),
    path('task_1/', task_1, name='task_1'),
    path('task_2/', task_2, name='task_2'),
    path('task_3/', task_3, name='task_3'),
]